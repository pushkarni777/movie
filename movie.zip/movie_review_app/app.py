'''from flask import Flask, request, jsonify, render_template
import psycopg2
from psycopg2 import sql
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
import os
from PIL import Image
import io

app = Flask(__name__)

# Enable CORS for the entire app
CORS(app)

# Secret key for JWT encoding/decoding
SECRET_KEY = 'this_is_secret_key_for_movie_reviews'

# Database connection configuration
DB_HOST = 'localhost'
DB_NAME = 'postgres'
DB_USER = 'postgres'
DB_PASSWORD = 'pushkarni'

# Function to get a database connection
def get_db_connection():
    connection = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    return connection

# Create tables if they don't exist
def create_tables():
    connection = get_db_connection()
    cursor = connection.cursor()
    
    # Create users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );
    """)
    
    # Create movie reviews table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id SERIAL PRIMARY KEY,
            movie_name TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            description TEXT,
            genre TEXT NOT NULL,
            username TEXT NOT NULL,
            image BYTEA,
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    # Create comments table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id SERIAL PRIMARY KEY,
            review_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            comment TEXT NOT NULL,
            FOREIGN KEY (review_id) REFERENCES reviews(id),
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    # Create reports table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id SERIAL PRIMARY KEY,
            review_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            reason TEXT NOT NULL,
            FOREIGN KEY (review_id) REFERENCES reviews(id),
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    connection.commit()
    cursor.close()
    connection.close()

create_tables()

# User registration
@app.route('/register', methods=['POST'])
def register():
    username = request.json.get('username')
    email = request.json.get('email')
    password = request.json.get('password')

    if not username or not email or not password:
        return jsonify({"error": "Username, email, and password are required."}), 400

    hashed_password = generate_password_hash(password)

    connection = get_db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute("""
            INSERT INTO users (username, email, password) VALUES (%s, %s, %s);
        """, (username, email, hashed_password))
        connection.commit()
    except psycopg2.IntegrityError:
        connection.rollback()
        return jsonify({"error": "Username or email already exists."}), 400
    finally:
        cursor.close()
        connection.close()

    return jsonify({"message": "User registered successfully."}), 201

# User login
@app.route('/signin', methods=['POST'])
def signin():
    username = request.json.get('username')
    password = request.json.get('password')

    if not username or not password:
        return jsonify({"error": "Username and password are required."}), 400

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT password FROM users WHERE username = %s;
    """, (username,))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if not user or not check_password_hash(user[0], password):
        return jsonify({"error": "Invalid credentials."}), 401

    expiration_time = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    token = jwt.encode({
        'username': username,
        'exp': expiration_time
    }, SECRET_KEY, algorithm='HS256')

    return jsonify({"message": "Signin successful.", "token": token})

# Create a movie review
@app.route('/reviews', methods=['POST'])
def create_review():
    token = request.headers.get('Authorization')
    movie_name = request.json.get('movie_name')
    rating = request.json.get('rating')
    description = request.json.get('description')
    genre = request.json.get('genre')
    image = request.files.get('image')

    if not token or not movie_name or not rating or not genre:
        return jsonify({"error": "Token, movie name, rating, and genre are required."}), 400

    try:
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        username = decoded_token['username']
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token has expired."}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token."}), 401

    image_bytes = image.read() if image else None

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO reviews (movie_name, rating, description, genre, username, image) 
        VALUES (%s, %s, %s, %s, %s, %s);
    """, (movie_name, rating, description, genre, username, image_bytes))
    connection.commit()
    cursor.close()
    connection.close()

    return jsonify({"message": "Review created successfully."}), 201

# View all reviews
@app.route('/reviews', methods=['GET'])
def view_reviews():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, movie_name, rating, description, genre, username FROM reviews;
    """)
    reviews = cursor.fetchall()
    cursor.close()
    connection.close()

    review_list = [{
        "id": review[0],
        "movie_name": review[1],
        "rating": review[2],
        "description": review[3],
        "genre": review[4],
        "username": review[5]
    } for review in reviews]

    return jsonify({"reviews": review_list}), 200

# Additional endpoints can be added for filtering, commenting, rating, searching, reporting, etc.

if __name__ == '__main__':
    app.run(debug=True)
'''


from flask import Flask, request, jsonify, render_template
import psycopg2
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime

app = Flask(__name__)

# Enable CORS for the entire app
CORS(app)

# Secret key for JWT encoding/decoding
SECRET_KEY = 'this_is_secret_key_for_movie_reviews'

# Database connection configuration
DB_HOST = 'localhost'
DB_NAME = 'postgres'
DB_USER = 'postgres'
DB_PASSWORD = 'pushkarni'

# Function to get a database connection
def get_db_connection():
    connection = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    return connection

# Create tables if they don't exist
def create_tables():
    connection = get_db_connection()
    cursor = connection.cursor()
    
    # Create users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );
    """)
    
    # Create movie reviews table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id SERIAL PRIMARY KEY,
            movie_name TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            description TEXT,
            genre TEXT NOT NULL,
            username TEXT NOT NULL,
            image BYTEA,
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    # Create comments table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id SERIAL PRIMARY KEY,
            review_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            comment TEXT NOT NULL,
            FOREIGN KEY (review_id) REFERENCES reviews(id),
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    # Create reports table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id SERIAL PRIMARY KEY,
            review_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            reason TEXT NOT NULL,
            FOREIGN KEY (review_id) REFERENCES reviews(id),
            FOREIGN KEY (username) REFERENCES users(username)
        );
    """)

    connection.commit()
    cursor.close()
    connection.close()

create_tables()
@app.route('/')
def home():
    return render_template('index.html')  # or whatever your homepage template is

# User registration route
@app.route('/register', methods=['POST'])
def register():
    username = request.json.get('username')
    email = request.json.get('email')
    password = request.json.get('password')

    if not username or not email or not password:
        return jsonify({"error": "Username, email, and password are required."}), 400

    hashed_password = generate_password_hash(password)

    connection = get_db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute("""
            INSERT INTO users (username, email, password) VALUES (%s, %s, %s);
        """, (username, email, hashed_password))
        connection.commit()
    except psycopg2.IntegrityError:
        connection.rollback()
        return jsonify({"error": "Username or email already exists."}), 400
    finally:
        cursor.close()
        connection.close()

    return jsonify({"message": "User registered successfully."}), 201

# User login route
@app.route('/signin', methods=['POST'])
def signin():
    username = request.json.get('username')
    password = request.json.get('password')

    if not username or not password:
        return jsonify({"error": "Username and password are required."}), 400

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT password FROM users WHERE username = %s;
    """, (username,))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if not user or not check_password_hash(user[0], password):
        return jsonify({"error": "Invalid credentials."}), 401

    expiration_time = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    token = jwt.encode({
        'username': username,
        'exp': expiration_time
    }, SECRET_KEY, algorithm='HS256')

    return jsonify({"message": "Signin successful.", "token": token})

# Create a movie review
@app.route('/reviews', methods=['POST'])
def create_review():
    token = request.headers.get('Authorization')
    movie_name = request.json.get('movie_name')
    rating = request.json.get('rating')
    description = request.json.get('description')
    genre = request.json.get('genre')
    image = request.files.get('image')

    if not token or not movie_name or not rating or not genre:
        return jsonify({"error": "Token, movie name, rating, and genre are required."}), 400

    try:
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        username = decoded_token['username']
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token has expired."}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token."}), 401

    image_bytes = image.read() if image else None

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO reviews (movie_name, rating, description, genre, username, image) 
        VALUES (%s, %s, %s, %s, %s, %s);
    """, (movie_name, rating, description, genre, username, image_bytes))
    connection.commit()
    cursor.close()
    connection.close()

    return jsonify({"message": "Review created successfully."}), 201

# View all reviews route
@app.route('/reviews', methods=['GET'])
def view_reviews():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, movie_name, rating, description, genre, username FROM reviews;
    """)
    reviews = cursor.fetchall()
    cursor.close()
    connection.close()

    review_list = [{
        "id": review[0],
        "movie_name": review[1],
        "rating": review[2],
        "description": review[3],
        "genre": review[4],
        "username": review[5]
    } for review in reviews]

    return jsonify({"reviews": review_list}), 200

# Add comment to a review
@app.route('/comments', methods=['POST'])
def add_comment():
    token = request.headers.get('Authorization')
    review_id = request.json.get('review_id')
    comment = request.json.get('comment')

    if not token or not review_id or not comment:
        return jsonify({"error": "Token, review_id, and comment are required."}), 400

    try:
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        username = decoded_token['username']
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token has expired."}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token."}), 401

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO comments (review_id, username, comment) 
        VALUES (%s, %s, %s);
    """, (review_id, username, comment))
    connection.commit()
    cursor.close()
    connection.close()

    return jsonify({"message": "Comment added successfully."}), 201

# Search movie reviews by movie name
@app.route('/search-reviews', methods=['GET'])
def search_reviews():
    movie_name = request.args.get('movie_name')

    if not movie_name:
        return jsonify({"error": "Movie name is required."}), 400

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, movie_name, rating, description, genre, username FROM reviews
        WHERE movie_name ILIKE %s;
    """, ('%' + movie_name + '%',))
    reviews = cursor.fetchall()
    cursor.close()
    connection.close()

    review_list = [{
        "id": review[0],
        "movie_name": review[1],
        "rating": review[2],
        "description": review[3],
        "genre": review[4],
        "username": review[5]
    } for review in reviews]

    return jsonify({"reviews": review_list}), 200

# Filter reviews by rating
@app.route('/filter-reviews', methods=['GET'])
def filter_reviews():
    rating = request.args.get('rating')

    if not rating:
        return jsonify({"error": "Rating is required."}), 400

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, movie_name, rating, description, genre, username FROM reviews
        WHERE rating = %s;
    """, (rating,))
    reviews = cursor.fetchall()
    cursor.close()
    connection.close()

    review_list = [{
        "id": review[0],
        "movie_name": review[1],
        "rating": review[2],
        "description": review[3],
        "genre": review[4],
        "username": review[5]
    } for review in reviews]

    return jsonify({"reviews": review_list}), 200

# Report a review as inappropriate
@app.route('/report-review', methods=['POST'])
def report_review():
    token = request.headers.get('Authorization')
    review_id = request.json.get('review_id')
    reason = request.json.get('reason')

    if not token or not review_id or not reason:
        return jsonify({"error": "Token, review_id, and reason are required."}), 400

    try:
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        username = decoded_token['username']
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token has expired."}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token."}), 401

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO reports (review_id, username, reason) 
        VALUES (%s, %s, %s);
    """, (review_id, username, reason))
    connection.commit()
    cursor.close()
    connection.close()

    return jsonify({"message": "Review reported successfully."}), 201

if __name__ == '__main__':
    app.run(debug=True)
